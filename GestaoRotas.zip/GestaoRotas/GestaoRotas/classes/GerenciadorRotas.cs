﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace GestaoRotas.classes
{
    public class GerenciadorRotas
    {
        public List<Rota> Rotas = new List<Rota>();

        public void AdicionarRota(int numero, string nome)
        {
            var rota = new Rota(numero, nome);
            Rotas.Add(rota);
        }
    }
}
