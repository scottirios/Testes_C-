﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace GestaoRotas.classes
{
    public class Rota
    {
        public List<Parada> Paradas = new List<Parada>();
        public int Numero { get; set; }
        public string Nome { get; set; }

        public Rota(int numeroRota, string nomeRota)
        {
            Numero = numeroRota;
            Nome = nomeRota;
        }

        public void AdicionarParada(Parada parada)
        {
            Paradas.Add(parada);
        }

    }
}
