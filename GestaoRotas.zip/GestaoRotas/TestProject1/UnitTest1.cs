using GestaoRotas.classes;

namespace TestProject1
{
    public class UnitTest1
    {
        [Fact]
        public void AdicionarRota_DeveAdicionarRotaValida()
        {
            //Arrange
            var gerenciadorRotas = new GerenciadorRotas();
            
            //Action
            gerenciadorRotas.AdicionarRota(1, "Marrecas");

            //Assert
            Assert.Single(gerenciadorRotas.Rotas);
            Assert.Equal(1, gerenciadorRotas.Rotas[0].Numero);
                        
        }

        [Fact]
        public void AdicionarParada_DeveAdicionarParadaValida()
        {
            //Arrange
            var parada = new Parada("Ponto", TimeSpan.Parse("19:30"), TimeSpan.Parse("20:30"));
            var rota = new Rota(2,"Centro");

            //Action
            rota.AdicionarParada(parada);

            //Assert
            Assert.Contains(parada, rota.Paradas);

        }

    }
}