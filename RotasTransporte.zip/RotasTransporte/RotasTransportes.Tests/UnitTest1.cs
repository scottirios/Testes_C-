using RotasTransporte.classes;

namespace RotasTransportes.Tests
{
    public class RotasTestes
    {
        [Fact]
        public void AdicionarRota_DeveAdicionarRotaValida()
        {
            //Arrange
            var rota = new GerenciadorRotas();
            int numeroRota = 1;
            string nomeRota = "Cantelmo";
            
            

            //Action
            rota.AdicionarRota(numeroRota, nomeRota);
            var rotaValida = new Rota(numeroRota, nomeRota);
            


            //Assert
            Assert.Equal(rotaValida, rota.BuscarRota);
        }
    }
}