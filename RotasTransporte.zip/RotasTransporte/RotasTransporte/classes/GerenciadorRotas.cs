﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RotasTransporte.classes
{
    public class GerenciadorRotas
    {
        List<Rota> Rotas {  get; set; }

        public GerenciadorRotas()
        {
            Rotas = new List<Rota>();

        }

        public void AdicionarRota(int numero, string nome)
        {
            var rota = new Rota(numero, nome);
            Rotas.Add(rota);
        }

        public void RemoverRota(int numero)
        {
            foreach (var rota in Rotas)
            {
                if (rota.numero == numero)
                {
                    Rotas.Remove(rota);
                }
            }
        }

        public Rota BuscarRota(int numero)
        {

        }

    }
}
