﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RotasTransporte.classes
{
    public class Rota
    {
        public List<Parada> _paradas = new List<Parada>();
        public int numero {  get; set; }
        public string nome { get; set; }

        public Rota(int numeroRota, string nomeRota)
        {
            numero = numeroRota;
            nome = nomeRota;
        }

        public void AdicionarParada(Parada parada)
        {
            _paradas.Add(parada);
        }

        public void RemoverParada(string nomeParada)
        {
            foreach (var parada in _paradas)
            {
                
            }
        }


    }





}
